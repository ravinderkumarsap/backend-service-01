package com.eclipse.mxd.model;

public class PropertiesModel {

}
