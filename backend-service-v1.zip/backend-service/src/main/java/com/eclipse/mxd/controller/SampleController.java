package com.eclipse.mxd.controller;

import com.eclipse.mxd.HibernateUtil;
import com.eclipse.mxd.entity.Employee;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import org.hibernate.Session;
import org.hibernate.Transaction;

@Path("/sample")
public class SampleController {

    @GET
    @Path("/hello")
    public Response sayHello() {

        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // start a transaction

            transaction = session.beginTransaction();
            // save the student object
            session.save(new Employee(1,"hello"));
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }

        String message = "hello";
        return Response.ok(message).build();
    }
}
