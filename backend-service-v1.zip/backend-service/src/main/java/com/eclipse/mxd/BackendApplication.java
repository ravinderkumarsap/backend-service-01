package com.eclipse.mxd;

import com.eclipse.mxd.controller.ContentController;
import com.eclipse.mxd.controller.TransferController;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@ApplicationPath("/api")
public class BackendApplication extends Application {



}